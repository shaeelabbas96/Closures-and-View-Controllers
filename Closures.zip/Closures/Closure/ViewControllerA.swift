//
//  ViewControllerA.swift
//  Closure
//
//  Created by Phaedra Solutions  on 08/07/2021.
//

import UIKit

class ViewControllerA: UIViewController {

    @IBOutlet weak var returnedLabel: UILabel!
    @IBAction func BtnPressed(_ sender: Any) {
        let vcb = ViewControllerB()
        
        
        vcb.completionHandler = { myString , myNum -> Void in
            self.returnedLabel.text = "\(myString) \(myNum)"
            print(myNum)
            
        }
        present(vcb, animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
    }
}
