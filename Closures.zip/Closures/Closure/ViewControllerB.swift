//
//  ViewControllerB.swift
//  Closure
//
//  Created by Phaedra Solutions  on 08/07/2021.
//

import UIKit

class ViewControllerB: UIViewController {
    var completionHandler: ((String,Int)->())?
    override func viewDidLoad() {
        super.viewDidLoad()
        

    }

    @IBAction func btnSendDataBack(_ sender: Any) {
        completionHandler?("Shaeel",24)
        dismiss(animated: true, completion: nil)
    }
    


}
